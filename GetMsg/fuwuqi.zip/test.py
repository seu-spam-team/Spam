import sys
import chilkat2
import time
# The Chilkat API can be unlocked for a fully-functional 30-day trial by passing any
# string to the UnlockBundle method.  A program can unlock once at the start. Once unlocked,
# all subsequently instantiated objects are created in the unlocked state.
#
# After licensing Chilkat, replace the "Anything for 30-day trial" with the purchased unlock code.
# To verify the purchased unlock code was recognized, examine the contents of the LastErrorText
# property after unlocking.  For example:
glob = chilkat2.Global()
success = glob.UnlockBundle("Anything for 30-day trial")
if (success != True):
    print(glob.LastErrorText)
    sys.exit()

status = glob.UnlockStatus
if (status == 2):
    print("Unlocked using purchased unlock code.")
else:
    print("Unlocked in trial mode.")

# The LastErrorText can be examined in the success case to see if it was unlocked in
# trial more, or with a purchased unlock code.
print(glob.LastErrorText)

# This example assumes the Chilkat API to have been previously unlocked.
# See Global Unlock Sample for sample code.

imap = chilkat2.Imap()

# Connect to an IMAP server.
# Use TLS
imap.Ssl = True
imap.Port = 993
success = imap.Connect("imap.163.com")
if (success != True):
    print(imap.LastErrorText)
    sys.exit()

# Login
success = imap.Login("haonan_0204@163.com","123456789asd")
if (success != True):
    print(imap.LastErrorText)
    sys.exit()
while True:
    # Select an IMAP mailbox
    time.sleep(5)
    success = imap.SelectMailbox("Inbox")
    if (success != True):
        print(imap.LastErrorText)
        sys.exit()

    # After selecting a mailbox, the NumMessages property
    # contains the number of emails in the selected mailbox.

    n = imap.NumMessages
    print(n)

