#coding: utf-8
import re
import os
#import time
#import random
#import jieba #处理中文，要加库
#import nltk #处理英文
#import sklearn #分类器用sklearn库
#from sklearn.naive_bayes import MultinomialNB #多项式模式  可以换成伯努利之类的
import numpy as np
#import pylab as pl
from urlextract import URLExtract
import main as url
import predict as pd



def classify(s,index=0.55):
    ## 文本预处理


    Engl = re.compile(r'[\u0061-\u007a,\u0020]')
    Chin = re.compile(r'[\u4e00-\u9fa5]')
    en = "".join(Engl.findall(s.lower()))
    cn = "".join(Chin.findall(s.lower()))

    extractor = URLExtract()
    urls = extractor.find_urls(s)

    if len(urls):
        index = index - 0.1721599 * url.main(urls)#恶意域名数量
        print(index)

    flag = 'sklearn'
    if 8*len(cn) > len(en):    #当英文文本量超过中文六倍时，判断为英文
        flag = 'sklearn'
        cnn = pd.CnnModel(flag)
        predict_result = cnn.predict(cn,flag)
    else:
        flag = 'nltk'
        cnn = pd.CnnModel(flag)
        predict_result = cnn.predict(en,flag)
    
    if predict_result > index:
        return False
    else:
        return True


